#include <iostream>
#include <vector>
#include <string>

std::vector<int> fixedNumberSet = {1, 2, 3, 4, 5, 6, 7, 8, 9};

bool isPossible(int target, std::string& expression, int idx, int currentSum, int lastNum) {
    if (idx == fixedNumberSet.size()) {
        return currentSum == target;
    }

    // Try addition
    expression.push_back('+');
    expression.append(std::to_string(fixedNumberSet[idx]));
    if (isPossible(target, expression, idx + 1, currentSum + fixedNumberSet[idx], fixedNumberSet[idx])) {
        return true;
    }
    expression.pop_back();
    expression.pop_back();

    // Try multiplication (if not the first number)
    if (idx != 0) {
        expression.push_back('*');
        expression.append(std::to_string(fixedNumberSet[idx]));
        if (isPossible(target, expression, idx + 1, currentSum - lastNum + lastNum * fixedNumberSet[idx], lastNum * fixedNumberSet[idx])) {
            return true;
        }
        expression.pop_back();
        expression.pop_back();
    }

    return false;
}

std::string findExpression(int target) {
    std::string expression;
    if (isPossible(target, expression, 0, fixedNumberSet[0], fixedNumberSet[0])) {
        expression = std::to_string(fixedNumberSet[0]) + expression + " = " + std::to_string(target);
        return expression;
    }
    return "No solution exists.";
}

int main() {
    int target;
    std::cout << "Enter the target number: ";
    std::cin >> target;

    std::string result = findExpression(target);
    std::cout << "Output: " << result << std::endl;

    return 0;
}
