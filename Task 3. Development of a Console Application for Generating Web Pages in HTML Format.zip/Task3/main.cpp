#include <iostream>
#include <fstream>
#include <string>
#include <vector>

// Define classes for HTML elements
class HTMLElement {
public:
    virtual std::string generateHTML() const = 0;
    virtual std::string getStyle() const { return ""; }
};

class Table : public HTMLElement {
public:
    std::string generateHTML() const override {
        int rows, cols;
        std::cout << "Enter number of rows: ";
        std::cin >> rows;
        std::cout << "Enter number of columns: ";
        std::cin >> cols;

        std::string html = "<table border='1'>";
        std::string cellStyles = getStyle();
        for (int i = 0; i < rows; ++i) {
            html += "<tr>";
            for (int j = 0; j < cols; ++j) {
                std::string cellContent;
                std::cout << "Enter content for cell (" << i + 1 << ", " << j + 1 << "): ";
                std::cin >> cellContent;
                html += "<td style='" + cellStyles + "'>" + cellContent + "</td>";
            }
            html += "</tr>";
        }
        html += "</table>";
        return html;
    }

    std::string getStyle() const override {
        std::string styles;
        std::cout << "Enter table cell styles (e.g., color: red; background-color: yellow): ";
        std::cin.ignore();
        std::getline(std::cin, styles);
        if (!styles.empty()) {
            return styles;
        }
        return "";
    }
};

class Form : public HTMLElement {
public:
    std::string generateHTML() const override {
        int numFields;
        std::cout << "Enter number of input fields: ";
        std::cin >> numFields;

        std::string html = "<form>";
        std::string formStyles = getStyle();
        for (int i = 0; i < numFields; ++i) {
            std::string inputType, inputName;
            std::cout << "Enter type for field " << i + 1 << " (e.g., text, password, etc.): ";
            std::cin >> inputType;
            std::cout << "Enter name for field " << i + 1 << ": ";
            std::cin >> inputName;
            html += "<label for='" + inputName + "'>" + inputName + ": </label>";
            html += "<input type='" + inputType + "' name='" + inputName + "' id='" + inputName + "'><br>";
        }
        html += "<input type='submit' value='Submit'></form>";
        return html;
    }

    std::string getStyle() const override {
        std::string styles;
        std::cout << "Enter form styles (e.g., border:1px solid black; padding:10px): ";
        std::cin.ignore();
        std::getline(std::cin, styles);
        if (!styles.empty()) {
            return styles;
        }
        return "";
    }
};

class NavigationBar : public HTMLElement {
public:
    std::string generateHTML() const override {
        std::vector<std::string> menuItems;
        int numItems;
        std::cout << "Enter number of items for navigation bar: ";
        std::cin >> numItems;

        std::string html = "<ul>";
        std::string navStyles = getStyle();
        for (int i = 0; i < numItems; ++i) {
            std::string item;
            std::cout << "Enter item " << i + 1 << ": ";
            std::cin >> item;
            menuItems.push_back(item);
            html += "<li><a href='#' style='" + navStyles + "'>" + item + "</a></li>";
        }
        html += "</ul>";
        return html;
    }

    std::string getStyle() const override {
        std::string styles;
        std::cout << "Enter navigation bar styles (e.g., background-color:lightblue; padding:5px): ";
        std::cin.ignore();
        std::getline(std::cin, styles);
        if (!styles.empty()) {
            return styles;
        }
        return "";
    }
};

class Article : public HTMLElement {
public:
    std::string generateHTML() const override {
        std::string title, content;
        std::cout << "Enter title for article: ";
        std::cin.ignore();
        std::getline(std::cin, title);
        std::cout << "Enter content for article: ";
        std::getline(std::cin, content);

        std::string html = "<article>";
        std::string articleStyles = getStyle();
        html += "<h2 style='" + articleStyles + "'>" + title + "</h2>";
        html += "<p style='" + articleStyles + "'>" + content + "</p>";
        html += "</article>";
        return html;
    }

    std::string getStyle() const override {
        std::string styles;
        std::cout << "Enter article styles (e.g., font-family:Arial; margin:20px): ";
        std::cin.ignore();
        std::getline(std::cin, styles);
        if (!styles.empty()) {
            return styles;
        }
        return "";
    }
};

// Implement interactive menu
void displayMenu() {
    std::cout << "Menu options:" << std::endl;
    std::cout << "1. Add Table" << std::endl;
    std::cout << "2. Add Form" << std::endl;
    std::cout << "3. Add Navigation Bar" << std::endl;
    std::cout << "4. Add Article" << std::endl;
}

// Collect user input for element details
HTMLElement* collectElementDetails() {
    int option;
    std::cout << "Enter option: ";
    std::cin >> option;
    switch (option) {
        case 1:
            return new Table();
        case 2:
            return new Form();
        case 3:
            return new NavigationBar();
        case 4:
            return new Article();
        default:
            std::cout << "Invalid option" << std::endl;
            return nullptr;
    }
}

// Generate HTML code based on user input
std::string generateHTMLCode() {
    std::string htmlCode;
    HTMLElement* element = collectElementDetails();
    if (element) {
        htmlCode = element->generateHTML();
        delete element;
    }
    return htmlCode;
}

// Write HTML code to file
void writeHTMLToFile(const std::string& htmlCode) {
    std::ofstream outFile("output.html");
    if (outFile.is_open()) {
        outFile << "<!DOCTYPE html>\n<html>\n<head>\n<title>Generated Page</title>\n</head>\n<body>\n";
        outFile << htmlCode;
        outFile << "\n</body>\n</html>";
        outFile.close();
        std::cout << "HTML page generated successfully!" << std::endl;
    } else {
        std::cerr << "Failed to open output file" << std::endl;
    }
}

int main() {
    // Display menu and collect user input
    displayMenu();

    // Generate HTML code
    std::string htmlCode = generateHTMLCode();

    // Write HTML code to file
    writeHTMLToFile(htmlCode);

    return 0;
}
