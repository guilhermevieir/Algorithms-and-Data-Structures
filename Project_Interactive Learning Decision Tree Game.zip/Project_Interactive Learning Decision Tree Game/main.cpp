#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>

struct Element {
    std::string info;
    int id, lid, rid;
};

std::vector<Element> data;
int data_length;

// Function to display game instructions
void displayInstructions() {
    std::cout << "\nWelcome to the guessing game!\n";
    std::cout << "Think of something and answer the questions with yes or no.\n";
    std::cout << "If the game doesn't guess correctly, please provide the correct answer and a question that distinguishes it from the failed attempt.\n\n";
}

// Function to validate user input
bool validateInput(char c) {
    return (toupper(c) == 'Y' || toupper(c) == 'N');
}

void load() {
    std::ifstream file("data.txt");
    if (!file.is_open()) {
        std::cerr << "Failed to open data.txt. Make sure the file exists and is accessible." << std::endl;
        return;
    }

    file >> data_length;
    data.resize(data_length + 1); // Resize to accommodate 1-based indexing
    for (int i = 1; i <= data_length; ++i) {
        file >> data[i].id >> data[i].lid >> data[i].rid;
        file.ignore(); // Ignore newline before reading string
        std::getline(file, data[i].info);
    }
    file.close();

    std::cout << "Data loaded from data.txt:" << std::endl;
}

void displayFileContents(const std::string& filename) {
    std::ifstream file("data.txt");
    if (file.is_open()) {
        std::string line;
        while (getline(file, line)) {
            std::cout << line << std::endl;
        }
        file.close();
    } else {
        std::cout << "Unable to open file: " << filename << std::endl;
    }
}

void save() {
    std::ofstream file("data.txt");
    file << data_length << std::endl;
    for (int i = 1; i <= data_length; ++i) {
        file << data[i].id << " " << data[i].lid << " " << data[i].rid << " " << data[i].info << std::endl;
    }
    file.close();
}

void updateTree(int index) {
    std::string correctAnswer, question;
    std::cout << "What is the correct answer? ";
    std::getline(std::cin, correctAnswer);
    std::cout << "What is the question distinguishing it? ";
    std::getline(std::cin, question);

    data_length++;
    data.push_back({data[index].info, data_length, 0, 0});
    data[index].rid = data_length;

    data_length++;
    data.push_back({correctAnswer, data_length, 0, 0});
    data[index].lid = data_length;

    data[index].info = question;

    save();
}

void game() {
    int index = 1;
    char c;
    while (data[index].lid != 0 && data[index].rid != 0) {
        std::cout << data[index].info << std::endl << "Yes/No?";
        std::cin >> c;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        if (!validateInput(c)) {
            std::cerr << "Invalid input. Please respond with Yes or No." << std::endl;
            continue;
        }
        if (toupper(c) == 'Y')
            index = data[index].lid;
        else
            index = data[index].rid;
    }
    std::cout << "Are you thinking of: " << data[index].info << "? Yes/No? ";
    std::cin >> c;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (!validateInput(c)) {
        std::cerr << "Invalid input. Please respond with Yes or No." << std::endl;
        return;
    }
    if (toupper(c) == 'N')
        updateTree(index);
}

void menu() {
    std::cout << "Welcome to the guessing game!\n";
    std::cout << "1. Instructions\n";
    std::cout << "2. Play the game\n";
    std::cout << "3. Debugging? See txt\n";
    std::cout << "4. Exit\n";
}

int main() {
    int choice;

    do {
        menu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                displayInstructions();
                break;
            case 2:
                load();
                game();
                break;
            case 3:
                displayFileContents("data.txt");
                break;
            case 4:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 4);


    return 0;
}

