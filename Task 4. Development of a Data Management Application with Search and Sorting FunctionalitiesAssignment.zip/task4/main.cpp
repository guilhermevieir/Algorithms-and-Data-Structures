#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

// Define Book class
class Book {
public:
    string title;
    string author;
    int year;
    // Add more attributes as needed

    // Constructor
    Book(string t, string a, int y) : title(t), author(a), year(y) {}
};

// Define Library class
class Library {
private:
    vector<Book> books; // List data structure to store books
    map<string, vector<Book*>> booksByAuthor; // Map data structure to store books by author
    string filename; // File to store books

public:
    // Constructor
    Library(string file) : filename(file) {
        // Load books from file
        loadBooksFromFile();
    }

    // Destructor
    ~Library() {
        // Save books to file
        saveBooksToFile();
    }

    // Load books from file
    void loadBooksFromFile() {
        ifstream infile(filename);
        if (!infile.is_open()) {
            cout << "Error: Unable to open file " << filename << endl;
            return;
        }

        string line;
        while (getline(infile, line)) {
            stringstream ss(line);
            string title, author;
            int year;
            getline(ss, title, ',');
            getline(ss, author, ',');
            ss >> year;
            addBook(Book(title, author, year));
        }

        infile.close();
    }

    // Save books to file
    void saveBooksToFile() {
        ofstream outfile(filename);
        if (!outfile.is_open()) {
            cout << "Error: Unable to open file " << filename << " for writing.\n";
            return;
        }

        for (const auto& book : books) {
            outfile << book.title << "," << book.author << "," << book.year << "\n";
        }

        outfile.close();
    }

    // Add book to library
    void addBook(const Book& book) {
        books.push_back(book);
        booksByAuthor[book.author].push_back(&books.back());
    }

    // Linear search by book title
    Book* linearSearchByTitle(const string& title) {
        for (auto& book : books) {
            if (book.title == title)
                return &book;
        }
        return nullptr; // Book not found
    }

    // Binary search by book title (requires sorted vector)
    Book* binarySearchByTitle(const string& title) {
        sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
            return a.title < b.title;
        });
        int low = 0, high = books.size() - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (books[mid].title == title)
                return &books[mid];
            else if (books[mid].title < title)
                low = mid + 1;
            else
                high = mid - 1;
        }
        return nullptr; // Book not found
    }

    // Linear search by keyword
    vector<Book*> linearSearchByKeyword(const string& keyword) {
        vector<Book*> result;
        for (auto& book : books) {
            if (book.title.find(keyword) != string::npos || book.author.find(keyword) != string::npos)
                result.push_back(&book);
        }
        return result;
    }

    // Binary search by keyword (requires sorted vector)
    vector<Book*> binarySearchByKeyword(const string& keyword) {
        sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
            return a.title < b.title;
        });

        vector<Book*> result;
        int low = 0, high = books.size() - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (books[mid].title.find(keyword) != string::npos || books[mid].author.find(keyword) != string::npos)
                result.push_back(&books[mid]);
            if (books[mid].title >= keyword)
                high = mid - 1;
            else
                low = mid + 1;
        }
        return result;
    }

    // Search books by author
    vector<Book*> searchByAuthor(const string& author) {
        if (booksByAuthor.find(author) != booksByAuthor.end())
            return booksByAuthor[author];
        else
            return {}; // Author not found
    }

    // Sorting by book title
    void sortByTitle() {
        sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
            return a.title < b.title;
        });
    }

    // Sorting by book author
    void sortByAuthor() {
        sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
            return a.author < b.author;
        });
    }

    // Display all books in library
    void displayAllBooks() {
        cout << "All Books in Library:\n";
        for (auto& book : books) {
            cout << book.title << " by " << book.author << " (" << book.year << ")\n";
        }
    }
};

// Function to display menu and get user choice
int getMenuChoice() {
    int choice;
    cout << "\nLibrary Management System Menu:\n";
    cout << "1. Add Book\n";
    cout << "2. Search Book by Title\n";
    cout << "3. Search Book by Author\n";
    cout << "4. Search Book by Keyword (Linear)\n";
    cout << "5. Search Book by Keyword (Binary)\n";
    cout << "6. Sort Books by Title\n";
    cout << "7. Sort Books by Author\n";
    cout << "8. Display All Books\n";
    cout << "9. Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;
    return choice;
}

int main() {
    string filename = "books.txt"; // File to store books
    // Create Library object
    Library library(filename);

    bool exit = false;
    while (!exit) {
        switch (getMenuChoice()) {
            case 1: {
                string title, author;
                int year;
                cout << "Enter book title: ";
                cin.ignore(); // Ignore newline character from previous input
                getline(cin, title);
                cout << "Enter author: ";
                getline(cin, author);
                cout << "Enter year of publication: ";
                cin >> year;
                library.addBook(Book(title, author, year));
                cout << "Book added successfully.\n";
                break;
            }
            case 2: {
                string title;
                cout << "Enter book title to search: ";
                cin.ignore();
                getline(cin, title);
                Book* foundBook = library.linearSearchByTitle(title);
                if (foundBook != nullptr) {
                    cout << "Book Found: " << foundBook->title << " by " << foundBook->author << " (" << foundBook->year << ")\n";
                } else {
                    cout << "Book not found\n";
                }
                break;
            }
            case 3: {
                string author;
                cout << "Enter author to search: ";
                cin.ignore();
                getline(cin, author);
                vector<Book*> booksByAuthor = library.searchByAuthor(author);
                if (!booksByAuthor.empty()) {
                    cout << "Books by " << author << ":\n";
                    for (auto book : booksByAuthor) {
                        cout << book->title << " (" << book->year << ")\n";
                    }
                } else {
                    cout << "No books found by " << author << "\n";
                }
                break;
            }
            case 4: {
                string keyword;
                cout << "Enter keyword to search: ";
                cin.ignore();
                getline(cin, keyword);
                vector<Book*> result = library.linearSearchByKeyword(keyword);
                if (!result.empty()) {
                    cout << "Books matching keyword \"" << keyword << "\":\n";
                    for (auto book : result) {
                        cout << book->title << " by " << book->author << " (" << book->year << ")\n";
                    }
                } else {
                    cout << "No books found matching keyword \"" << keyword << "\"\n";
                }
                break;
            }
            case 5: {
                string keyword;
                cout << "Enter keyword to search: ";
                cin.ignore();
                getline(cin, keyword);
                vector<Book*> result = library.binarySearchByKeyword(keyword);
                if (!result.empty()) {
                    cout << "Books matching keyword \"" << keyword << "\":\n";
                    for (auto book : result) {
                        cout << book->title << " by " << book->author << " (" << book->year << ")\n";
                    }
                } else {
                    cout << "No books found matching keyword \"" << keyword << "\"\n";
                }
                break;
            }
            case 6: {
                library.sortByTitle();
                cout << "Books sorted by title.\n";
                break;
            }
            case 7: {
                library.sortByAuthor();
                cout << "Books sorted by author.\n";
                break;
            }
            case 8: {
                library.displayAllBooks();
                break;
            }
            case 9: {
                exit = true;
                cout << "Exiting...\n";
                break;
            }
            default: {
                cout << "Invalid choice. Please enter a number between 1 and 9.\n";
                break;
            }
        }
    }

    return 0;
}
