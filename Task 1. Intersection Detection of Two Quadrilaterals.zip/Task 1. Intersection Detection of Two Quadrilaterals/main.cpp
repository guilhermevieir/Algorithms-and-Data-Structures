#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

class Point {
public:
    double x, y;

    Point(double x = 0, double y = 0) : x(x), y(y) {}
};

class Quadrilateral {
public:
    Point A, B, C, D;

    Quadrilateral(Point A, Point B, Point C, Point D) : A(A), B(B), C(C), D(D) {}

    // Function to check if two line segments intersect
    static bool doIntersect(Point p1, Point q1, Point p2, Point q2) {
        return (max(p1.x, q1.x) >= min(p2.x, q2.x) && max(p2.x, q2.x) >= min(p1.x, q1.x) &&
                max(p1.y, q1.y) >= min(p2.y, q2.y) && max(p2.y, q2.y) >= min(p1.y, q1.y));
    }

    // Function to check if the two quadrilaterals intersect using Separating Axis
    static bool doQuadrilateralsIntersect(const Quadrilateral& q1, const Quadrilateral& q2) {
        vector<Point> axes = {getNormal(q1.A, q1.B), getNormal(q1.B, q1.C), getNormal(q2.A, q2.B), getNormal(q2.B, q2.C)};

        for (const auto& axis : axes) {
            if (!isOverlap(q1, q2, axis)) {
                return false;
            }
        }

        return true;
    }

private:
    // Function to get the normal vector of a line segment
    static Point getNormal(Point p1, Point p2) {
        Point normal(p2.y - p1.y, p1.x - p2.x);
        return normal;
    }

    // Function to project a quadrilateral onto an axis
    static void projectOntoAxis(const Quadrilateral& q, const Point& axis, double& minProjection, double& maxProjection) {
        double projection = (q.A.x * axis.x + q.A.y * axis.y);
        minProjection = maxProjection = projection;

        projection = (q.B.x * axis.x + q.B.y * axis.y);
        minProjection = min(minProjection, projection);
        maxProjection = max(maxProjection, projection);

        projection = (q.C.x * axis.x + q.C.y * axis.y);
        minProjection = min(minProjection, projection);
        maxProjection = max(maxProjection, projection);

        projection = (q.D.x * axis.x + q.D.y * axis.y);
        minProjection = min(minProjection, projection);
        maxProjection = max(maxProjection, projection);
    }

    // Function to check if two projections overlap on an axis
    static bool isOverlap(const Quadrilateral& q1, const Quadrilateral& q2, const Point& axis) {
        double minProjection1, maxProjection1, minProjection2, maxProjection2;

        projectOntoAxis(q1, axis, minProjection1, maxProjection1);
        projectOntoAxis(q2, axis, minProjection2, maxProjection2);

        return !(maxProjection1 < minProjection2 || maxProjection2 < minProjection1);
    }
};

int main() {
    // Input for Quadrilateral 1
    cout << "Enter coordinates for Quadrilateral 1 (A B C D): ";
    Point A1, B1, C1, D1;
    cin >> A1.x >> A1.y >> B1.x >> B1.y >> C1.x >> C1.y >> D1.x >> D1.y;
    Quadrilateral quad1(A1, B1, C1, D1);

    // Input for Quadrilateral 2
    cout << "Enter coordinates for Quadrilateral 2 (E F G H): ";
    Point A2, B2, C2, D2;
    cin >> A2.x >> A2.y >> B2.x >> B2.y >> C2.x >> C2.y >> D2.x >> D2.y;
    Quadrilateral quad2(A2, B2, C2, D2);

    // Check if the quadrilaterals intersect
    if (Quadrilateral::doQuadrilateralsIntersect(quad1, quad2)) {
        cout << "Intersect" << endl;
    } else {
        cout << "Do Not Intersect" << endl;
    }

    return 0;
}
